public class Test {
    public static void main(String[] args) {
        Maze maze = new Maze("maze.txt");
        maze.showPath();
    }
}
